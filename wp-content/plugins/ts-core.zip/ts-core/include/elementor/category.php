<?php
namespace TSCore\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use \Elementor\Group_Control_Background;
use \Elementor\Group_Control_Image_Size;
use \Elementor\Repeater;
use \Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/**
 * Ts Core
 *
 * Elementor widget for hello world.
 *
 * @since 1.0.0
 */
class TS_Categories extends Widget_Base {
    use TS_Style_Trait;
    /**
     * Retrieve the widget name.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget name.
     */
    public function get_name() {
        return 'ts-categories';
    }

    /**
     * Retrieve the widget title.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget title.
     */
    public function get_title() {
        return __( 'Categories', 'TScore' );
    }

    /**
     * Retrieve the widget icon.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return string Widget icon.
     */
    public function get_icon() {
        return 'ts-icon';
    }

    /**
     * Retrieve the list of categories the widget belongs to.
     *
     * Used to determine where to display the widget in the editor.
     *
     * Note that currently Elementor supports only one category.
     * When multiple categories passed, Elementor uses the first one.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget categories.
     */
    public function get_categories() {
        return [ 'TScore' ];
    }

    /**
     * Retrieve the list of scripts the widget depended on.
     *
     * Used to set scripts dependencies required to run the widget.
     *
     * @since 1.0.0
     *
     * @access public
     *
     * @return array Widget scripts dependencies.
     */
    public function get_script_depends() {
        return [ 'TScore' ];
    }

    protected function register_controls()
    {
        $this->register_controls_section();
        $this->style_tab_content();
    }

    /**
     * Register the widget controls.
     *
     * Adds different input fields to allow the user to change and customize the widget settings.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function register_controls_section() {

        // layout Panel
        $this->start_controls_section(
            'TS_layout',
            [
                'label' => esc_html__('Design Layout', 'TScore'),
            ]
        );
        $this->add_control(
            'TS_design_style',
            [
                'label' => esc_html__('Select Layout', 'TScore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    'layout-1' => esc_html__('Layout 1', 'TScore'),
                ],
                'default' => 'layout-1',
            ]
        );

        $this->end_controls_section();

        // TS_section_title
        $this->start_controls_section(
            'TS_section_title',
            [
                'label' => esc_html__('Title & Content', 'TScore'),
            ]
        );

        $this->add_control(
            'TS_section_title_show',
            [
                'label' => esc_html__( 'Section Title & Content', 'TScore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'TScore' ),
                'label_off' => esc_html__( 'Hide', 'TScore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'TS_sub_title',
            [
                'label' => esc_html__('Sub Title', 'TScore'),
                'description' => TS_get_allowed_html_desc( 'basic' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('TS Sub Title', 'TScore'),
                'placeholder' => esc_html__('Type Sub Heading Text', 'TScore'),
                'label_block' => true,
            ]
        );
        $this->add_control(
            'TS_title',
            [
                'label' => esc_html__('Title', 'TScore'),
                'description' => TS_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('TS Title Here', 'TScore'),
                'placeholder' => esc_html__('Type Heading Text', 'TScore'),
                'label_block' => true,
            ]
        );

        $this->add_control(
            'TS_desctiption',
            [
                'label' => esc_html__('Description', 'TScore'),
                'description' => TS_get_allowed_html_desc( 'intermediate' ),
                'type' => Controls_Manager::TEXTAREA,
                'default' => esc_html__('TS section description here', 'TScore'),
                'placeholder' => esc_html__('Type section description here', 'TScore'),
            ]
        );

        $this->add_control(
            'TS_title_tag',
            [
                'label' => esc_html__('Title HTML Tag', 'TScore'),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'h1' => [
                        'title' => esc_html__('H1', 'TScore'),
                        'icon' => 'eicon-editor-h1'
                    ],
                    'h2' => [
                        'title' => esc_html__('H2', 'TScore'),
                        'icon' => 'eicon-editor-h2'
                    ],
                    'h3' => [
                        'title' => esc_html__('H3', 'TScore'),
                        'icon' => 'eicon-editor-h3'
                    ],
                    'h4' => [
                        'title' => esc_html__('H4', 'TScore'),
                        'icon' => 'eicon-editor-h4'
                    ],
                    'h5' => [
                        'title' => esc_html__('H5', 'TScore'),
                        'icon' => 'eicon-editor-h5'
                    ],
                    'h6' => [
                        'title' => esc_html__('H6', 'TScore'),
                        'icon' => 'eicon-editor-h6'
                    ]
                ],
                'default' => 'h2',
                'toggle' => false,
            ]
        );
        $this->end_controls_section();

        // TS_btn_button_group
        $this->start_controls_section(
            'TS_btn_button_group',
            [
                'label' => esc_html__('Button', 'TScore'),
            ]
        );

        $this->add_control(
            'TS_btn_button_show',
            [
                'label' => esc_html__( 'Show Button', 'TScore' ),
                'type' => Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Show', 'TScore' ),
                'label_off' => esc_html__( 'Hide', 'TScore' ),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
            'TS_btn_text',
            [
                'label' => esc_html__('Button Text', 'TScore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('Button Text', 'TScore'),
                'title' => esc_html__('Enter button text', 'TScore'),
                'label_block' => true,
                'condition' => [
                    'TS_btn_button_show' => 'yes'
                ],
            ]
        );
        $this->add_control(
            'TS_btn_link_type',
            [
                'label' => esc_html__('Button Link Type', 'TScore'),
                'type' => Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'label_block' => true,
                'condition' => [
                    'TS_btn_button_show' => 'yes'
                ],
            ]
        );

        $this->add_control(
            'TS_btn_link',
            [
                'label' => esc_html__('Button link', 'TScore'),
                'type' => Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__('htTSs://your-link.com', 'TScore'),
                'show_external' => false,
                'default' => [
                    'url' => '#',
                    'is_external' => true,
                    'nofollow' => true,
                    'custom_attributes' => '',
                ],
                'condition' => [
                    'TS_btn_link_type' => '1',
                    'TS_btn_button_show' => 'yes'
                ],
                'label_block' => true,
            ]
        );
        $this->add_control(
            'TS_btn_page_link',
            [
                'label' => esc_html__('Select Button Page', 'TScore'),
                'type' => Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => TS_get_all_pages(),
                'condition' => [
                    'TS_btn_link_type' => '2',
                    'TS_btn_button_show' => 'yes'
                ]
            ]
        );

        $this->end_controls_section();

        // Service group
        $this->start_controls_section(
            'TS_categories',
            [
                'label' => esc_html__('Category List', 'TScore'),
                'description' => esc_html__( 'Control all the style settings from Style tab', 'TScore' ),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $repeater = new \Elementor\Repeater();

        $repeater->start_controls_tabs(
            '_tab_style_member_box_itemr'
        );

        $repeater->start_controls_tab(
            '_tab_cat_normal',
            [
                'label' => __( 'Icon Color', 'TScore' ),
            ]
        );

        $repeater->add_control(
            'TS_cat_icon_bg_color',
            [
                'label' => __( 'Icon BG Color', 'tocore' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#ECF0FF',
                'frontend_available' => true,
                'selectors' => [
                     '{{WRAPPER}} {{CURRENT_ITEM}} .category__icon a' => 'background-color: {{VALUE}};',
                ],
                'style_transfer' => true,
                'frontend_available' => true,
            ]
        );

        $repeater->add_control(
            'TS_cat_icon_color',
            [
                'label' => __( 'Icon Color', 'tocore' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#4270FF',
                'frontend_available' => true,
                'selectors' => [
                     '{{WRAPPER}} {{CURRENT_ITEM}} .category__icon a' => 'color: {{VALUE}};',
                ],
                'style_transfer' => true,
                'frontend_available' => true,
            ]
        );
        $repeater->end_controls_tab();

        $repeater->start_controls_tab(
            '_tab_cat_hover',
            [
                'label' => __( 'Icon Hover Color', 'TScore' ),
            ]
        );
        $repeater->add_control(
            'TS_cat_icon_bg_hover_color',
            [
                'label' => __( 'Icon BG Hover Color', 'tocore' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#4270FF',
                'frontend_available' => true,
                'selectors' => [
                     '{{WRAPPER}} {{CURRENT_ITEM}}.category__item:hover .category__icon a' => 'background-color: {{VALUE}};',
                ],
                'style_transfer' => true,
                'frontend_available' => true,
            ]
        );

        $repeater->add_control(
            'TS_cat_icon_hover_color',
            [
                'label' => __( 'Icon Hover Color', 'tocore' ),
                'type' => Controls_Manager::COLOR,
                'default' => '#fff',
                'frontend_available' => true,
                'selectors' => [
                     '{{WRAPPER}} {{CURRENT_ITEM}}.category__item:hover .category__icon a' => 'color: {{VALUE}};',
                ],
                'style_transfer' => true,
                'frontend_available' => true,
            ]
        );

        $repeater->end_controls_tab();
        $repeater->end_controls_tabs();
        // icon tab end

        $repeater->add_control(
            'TS_features_icon_type',
            [
                'label' => esc_html__('Select Icon Type', 'TScore'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'default' => 'icon',
                'options' => [
                    'image' => esc_html__('Image', 'TScore'),
                    'icon' => esc_html__('Icon', 'TScore'),
                ],
            ]
        );

        $repeater->add_control(
            'TS_features_image',
            [
                'label' => esc_html__('Upload Icon Image', 'TScore'),
                'type' => Controls_Manager::MEDIA,
                'default' => [
                    'url' => Utils::get_placeholder_image_src(),
                ],
                'condition' => [
                    'TS_features_icon_type' => 'image'
                ]

            ]
        );

        if (TS_is_elementor_version('<', '2.6.0')) {
            $repeater->add_control(
                'TS_features_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICON,
                    'label_block' => true,
                    'default' => 'eicon-star-o',
                    'condition' => [
                        'TS_features_icon_type' => 'icon'
                    ]
                ]
            );
        } else {
            $repeater->add_control(
                'TS_features_selected_icon',
                [
                    'show_label' => false,
                    'type' => Controls_Manager::ICONS,
                    'fa4compatibility' => 'icon',
                    'label_block' => true,
                    'default' => [
                        'value' => 'fas fa-star',
                        'library' => 'solid',
                    ],
                    'condition' => [
                        'TS_features_icon_type' => 'icon'
                    ]
                ]
            );
        }

        $repeater->add_control(
            'TS_service_title', [
                'label' => esc_html__('Title', 'TScore'),
                'description' => TS_get_allowed_html_desc( 'basic' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Service Title', 'TScore'),
                'label_block' => true,
            ]
        );

        $repeater->add_control(
            'TS_services_link_switcher',
            [
                'label' => esc_html__( 'Add Services link', 'TScore' ),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => esc_html__( 'Yes', 'TScore' ),
                'label_off' => esc_html__( 'No', 'TScore' ),
                'return_value' => 'yes',
                'default' => 'yes',
                'separator' => 'before',
            ]
        );
        $repeater->add_control(
            'TS_services_link_type',
            [
                'label' => esc_html__( 'Service Link Type', 'TScore' ),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    '1' => 'Custom Link',
                    '2' => 'Internal Page',
                ],
                'default' => '1',
                'condition' => [
                    'TS_services_link_switcher' => 'yes'
                ]
            ]
        );
        $repeater->add_control(
            'TS_services_link',
            [
                'label' => esc_html__( 'Service Link link', 'TScore' ),
                'type' => \Elementor\Controls_Manager::URL,
                'dynamic' => [
                    'active' => true,
                ],
                'placeholder' => esc_html__( 'htTSs://your-link.com', 'TScore' ),
                'show_external' => true,
                'default' => [
                    'url' => '#',
                    'is_external' => false,
                    'nofollow' => false,
                ],
                'condition' => [
                    'TS_services_link_type' => '1',
                    'TS_services_link_switcher' => 'yes',
                ]
            ]
        );
        $repeater->add_control(
            'TS_services_page_link',
            [
                'label' => esc_html__( 'Select Service Link Page', 'TScore' ),
                'type' => \Elementor\Controls_Manager::SELECT2,
                'label_block' => true,
                'options' => TS_get_all_pages(),
                'condition' => [
                    'TS_services_link_type' => '2',
                    'TS_services_link_switcher' => 'yes',
                ]
            ]
        );

        $this->add_control(
            'TS_service_list',
            [
                'label' => esc_html__('Services - List', 'TScore'),
                'type' => \Elementor\Controls_Manager::REPEATER,
                'fields' => $repeater->get_controls(),
                'default' => [
                    [
                        'TS_service_title' => esc_html__('Business Stratagy', 'TScore'),
                    ],
                    [
                        'TS_service_title' => esc_html__('Website Development', 'TScore')
                    ],
                    [
                        'TS_service_title' => esc_html__('Marketing & Reporting', 'TScore')
                    ]
                ],
                'title_field' => '{{{ TS_service_title }}}',
            ]
        );

        $this->add_control(
            'TS_course_link',
            [
                'label' => esc_html__('More Button Link', 'TScore'),
                'type' => Controls_Manager::TEXT,
                'default' => esc_html__('#', 'TScore'),
                'placeholder' => esc_html__('Course Link', 'TScore'),
                'label_block' => true,
            ]
        );

        $this->add_responsive_control(
            'TS_service_align',
            [
                'label' => esc_html__( 'Alignment', 'TScore' ),
                'type' => Controls_Manager::CHOOSE,
                'options' => [
                    'text-left' => [
                        'title' => esc_html__( 'Left', 'TScore' ),
                        'icon' => 'eicon-text-align-left',
                    ],
                    'text-center' => [
                        'title' => esc_html__( 'Center', 'TScore' ),
                        'icon' => 'eicon-text-align-center',
                    ],
                    'text-right' => [
                        'title' => esc_html__( 'Right', 'TScore' ),
                        'icon' => 'eicon-text-align-right',
                    ],
                ],
                'toggle' => true,
                'separator' => 'before',
            ]
        );

        $this->add_group_control(
            Group_Control_Image_Size::get_type(),
            [
                'name' => 'thumbnail', // // Usage: `{name}_size` and `{name}_custom_dimension`, in this case `thumbnail_size` and `thumbnail_custom_dimension`.
                'exclude' => ['custom'],
                // 'default' => 'ts-post-thumb',
            ]
        );
        $this->end_controls_section();
    }

    protected function style_tab_content()
    {
        $this->TS_section_style_controls('about_section', 'Section', '.ts-el-sec');
        $this->TS_basic_style_controls('heading_title', 'Title', '.ts-el-title');
        $this->TS_basic_style_controls('heading_subtitle', 'Subtitle', '.ts-el-subtitle');
        $this->TS_basic_style_controls('heading_desc', 'Description', '.ts-el-content');
        $this->TS_basic_style_controls('cat_title', 'Category Title', '.ts-el-cat');
        $this->TS_link_controls_style('', 'b_btn1_style', 'Button', '.ts-el-btn');
    }


    /**
     * Render the widget ouTSut on the frontend.
     *
     * Written in PHP and used to generate the final HTML.
     *
     * @since 1.0.0
     *
     * @access protected
     */
    protected function render() {
        $settings = $this->get_settings_for_display();

        ?>

        <?php if ( $settings['TS_design_style']  == 'layout-2' ):
            $this->add_render_attribute('title_args', 'class', 'sectionTitle__big');
        ?>

        <?php else:
            $this->add_render_attribute('title_args', 'class', 'section__title-2 section__title-2-30 ts-el-title');
            // Link
            if ('2' == $settings['TS_btn_link_type']) {
                $this->add_render_attribute('ts-button-arg', 'href', get_permalink($settings['TS_btn_page_link']));
                $this->add_render_attribute('ts-button-arg', 'target', '_self');
                $this->add_render_attribute('ts-button-arg', 'rel', 'nofollow');
                $this->add_render_attribute('ts-button-arg', 'class', 'ts-btn-5');
            } else {
                if ( ! empty( $settings['TS_btn_link']['url'] ) ) {
                    $this->add_link_attributes( 'ts-button-arg', $settings['TS_btn_link'] );
                    $this->add_render_attribute('ts-button-arg', 'class', 'ts-btn-5 ts-el-btn');
                }
            }
        ?>

         <section class="category__area ts-el-sec">
            <div class="container">
               <div class="row">
                  <?php if ( !empty($settings['TS_section_title_show']) ) : ?>
                  <div class="col-xxl-4 col-xl-4 col-lg-4">
                     <div class="category__wrapper">
                        <div class="section__title-wrapper-2">
                            <?php if ( !empty($settings['TS_sub_title']) ) : ?>
                            <span class="section__title-pre-2 ts-el-subtitle">
                                <?php echo TS_kses( $settings['TS_sub_title'] ); ?>
                            </span>
                            <?php endif; ?>
                            <?php
                                if ( !empty($settings['TS_title' ]) ) :
                                    printf( '<%1$s %2$s>%3$s</%1$s>',
                                        tag_escape( $settings['TS_title_tag'] ),
                                        $this->get_render_attribute_string( 'title_args' ),
                                        TS_kses( $settings['TS_title' ] )
                                        );
                                endif;
                            ?>
                        </div>
                        <?php if ( !empty($settings['TS_desctiption']) ) : ?>
                            <p class="ts-el-content" ><?php echo TS_kses( $settings['TS_desctiption'] ); ?></p>
                        <?php endif; ?>

                        <?php if (!empty($settings['TS_btn_text'])) : ?>
                        <div class="category__btn">
                            <a <?php echo $this->get_render_attribute_string( 'ts-button-arg' ); ?>>
                                <?php echo $settings['TS_btn_text']; ?>
                            </a>
                        </div>
                        <?php endif; ?>
                     </div>
                  </div>
                  <?php endif; ?>

                  <div class="col-xxl-8 col-xl-8 col-lg-8">
                     <div class="category__item-wrapper">
                        <div class="row">
                            <?php foreach ($settings['TS_service_list'] as $item) :
                                // Link
                                if ('2' == $item['TS_services_link_type']) {
                                    $link = get_permalink($item['TS_services_page_link']);
                                    $target = '_self';
                                    $rel = 'nofollow';
                                } else {
                                    $link = !empty($item['TS_services_link']['url']) ? $item['TS_services_link']['url'] : '';
                                    $target = !empty($item['TS_services_link']['is_external']) ? '_blank' : '';
                                    $rel = !empty($item['TS_services_link']['nofollow']) ? 'nofollow' : '';
                                }
                            ?>
                           <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-3 col-sm-4 col-6">
                              <div class="category__item elementor-repeater-item-<?php echo esc_attr($item['_id']); ?> text-center mb-45">
                                 <div class="category__icon">
                                    <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>">
                                        <?php if($item['TS_features_icon_type'] !== 'image') : ?>
                                            <?php if (!empty($item['TS_features_icon']) || !empty($item['TS_features_selected_icon']['value'])) : ?>
                                                <span class="cat__icon"><?php TS_render_icon($item, 'TS_features_icon', 'TS_features_selected_icon'); ?></span>
                                            <?php endif; ?>
                                        <?php else : ?>
                                            <span class="cat__icon">
                                                <?php if (!empty($item['TS_features_image']['url'])): ?>
                                                <img class="light" src="<?php echo $item['TS_features_image']['url']; ?>" alt="<?php echo get_post_meta(attachment_url_to_postid($item['TS_features_image']['url']), '_wp_attachment_image_alt', true); ?>">
                                                <?php endif; ?>
                                            </span>
                                        <?php endif; ?>
                                    </a>
                                 </div>
                                 <div class="category__content">
                                    <?php if (!empty($item['TS_service_title' ])): ?>
                                    <h4 class="category__title ts-el-cat">
                                       <a target="<?php echo esc_attr($target); ?>" rel="<?php echo esc_attr($rel); ?>" href="<?php echo esc_url($link); ?>"><?php echo TS_kses($item['TS_service_title' ]); ?></a>
                                    </h4>
                                    <?php endif; ?>
                                 </div>
                              </div>
                           </div>
                           <?php endforeach; ?>

                           <?php if (!empty($settings['TS_course_link'])): ?>
                           <div class="col-xxl-2 col-xl-2 col-lg-3 col-md-3 col-sm-4 col-6">
                              <div class="category__item text-center mb-45">
                                 <div class="category__icon add">
                                    <a href="<?php echo esc_url($settings['TS_course_link']); ?>">+</a>
                                 </div>
                                 <div class="category__content">
                                    <h4 class="category__title add">
                                       <a href="<?php echo esc_url($settings['TS_course_link']); ?>"><?php echo esc_html__('All Course','TScore'); ?></a>
                                    </h4>
                                 </div>
                              </div>
                           </div>
                           <?php endif; ?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </section>

        <?php endif; ?>

        <?php
    }
}

$widgets_manager->register( new TS_Categories() );